﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ctrComissao
{
    public class clsVendedor
    {
        SqlConnection cn = new SqlConnection(); // Faz a conexão com o banco
        SqlCommand cmd = new SqlCommand(); // Permite utilizar os comandos: insert, update, delete, select
        DataTable dt = new DataTable(); // Permite selecionar os registros da tabela

        public void inserir(string nome_vendedor, string email, string contato, double percentual_comissao)
        {
            SqlConnection cn = new SqlConnection(clsConexao.StringConexao);
            try
            {
                cn.Open();
                string SQL = "INSERT INTO tbvendedor (nome_vendedor, email, contato, percentual_comissao)";
                SQL += " VALUES (@nome_vendedor, @email, @contato, @percentual_comissao)";
                cmd.Connection = cn;
                cmd.Parameters.Add(new SqlParameter("@nome_vendedor", nome_vendedor));
                cmd.Parameters.Add(new SqlParameter("@email", email));
                cmd.Parameters.Add(new SqlParameter("@contato", contato));
                cmd.Parameters.Add(new SqlParameter("@percentual_comissao", percentual_comissao));
                cmd.CommandText = SQL.ToString();
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
                cmd.Dispose();
            }
        }

        public void editar(int codigo, string nome_vendedor, string email, string contato, double percentual_comissao)
        {
            SqlConnection cn = new SqlConnection(clsConexao.StringConexao);
            try
            {
                cn.Open();
                string SQL = "UPDATE tbvendedor SET nome_vendedor = @nome_vendedor, email = @email, contato = @contato, percentual_comissao = @percentual_comissao WHERE codigo = @codigo";
                
                cmd.Connection = cn;
                cmd.Parameters.Add(new SqlParameter("@codigo", codigo));
                cmd.Parameters.Add(new SqlParameter("@nome_vendedor", nome_vendedor));
                cmd.Parameters.Add(new SqlParameter("@email", email));
                cmd.Parameters.Add(new SqlParameter("@contato", contato));
                cmd.Parameters.Add(new SqlParameter("@percentual_comissao", percentual_comissao));
                cmd.CommandText = SQL.ToString();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
                cmd.Dispose();
            }
        }

        public DataTable PesquisaCodigo(int codigo)
        {
            SqlConnection cn = new SqlConnection(clsConexao.StringConexao);

            try
            {
                cn.Open(); // Abre a conexão
                string SQL = "SELECT * FROM tbvendedor WHERE codigo = @codigo";
                SqlCommand cmd = new SqlCommand(SQL, cn);
                cmd.Parameters.Add(new SqlParameter("@codigo", codigo));

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
                cmd.Dispose();
            }
        }

        public DataTable PesquisaVendedor(string vendedor)
        {
            SqlConnection cn = new SqlConnection(clsConexao.StringConexao);

            try
            {
                cn.Open(); // Abre a conexão
                string SQL = "SELECT * FROM tbvendedor WHERE nome_vendedor LIKE '%' + nome_vendedor + '%'";
                SqlCommand cmd = new SqlCommand(SQL, cn);
                cmd.Parameters.Add(new SqlParameter("@vendedor", vendedor));

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
                cmd.Dispose();
            }
        }
    }
}
