﻿namespace ctrComissao
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mmMenu = new System.Windows.Forms.MenuStrip();
            this.mnuArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemSair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCadastro = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemVendedor = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuControle = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemComissao = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAjuda = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemSobre = new System.Windows.Forms.ToolStripMenuItem();
            this.mmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // mmMenu
            // 
            this.mmMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuArquivo,
            this.mnuCadastro,
            this.mnuControle,
            this.mnuAjuda});
            this.mmMenu.Location = new System.Drawing.Point(0, 0);
            this.mmMenu.Name = "mmMenu";
            this.mmMenu.Size = new System.Drawing.Size(800, 28);
            this.mmMenu.TabIndex = 0;
            this.mmMenu.Text = "menuStrip1";
            // 
            // mnuArquivo
            // 
            this.mnuArquivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemSair});
            this.mnuArquivo.Name = "mnuArquivo";
            this.mnuArquivo.Size = new System.Drawing.Size(75, 24);
            this.mnuArquivo.Text = "&Arquivo";
            // 
            // mnuItemSair
            // 
            this.mnuItemSair.Name = "mnuItemSair";
            this.mnuItemSair.Size = new System.Drawing.Size(117, 26);
            this.mnuItemSair.Text = "Sai&r";
            this.mnuItemSair.Click += new System.EventHandler(this.mnuItemSair_Click);
            // 
            // mnuCadastro
            // 
            this.mnuCadastro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemVendedor});
            this.mnuCadastro.Name = "mnuCadastro";
            this.mnuCadastro.Size = new System.Drawing.Size(82, 24);
            this.mnuCadastro.Text = "&Cadastro";
            // 
            // mnuItemVendedor
            // 
            this.mnuItemVendedor.Name = "mnuItemVendedor";
            this.mnuItemVendedor.Size = new System.Drawing.Size(156, 26);
            this.mnuItemVendedor.Text = "&Vendedor";
            this.mnuItemVendedor.Click += new System.EventHandler(this.mnuItemVendedor_Click);
            // 
            // mnuControle
            // 
            this.mnuControle.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemComissao});
            this.mnuControle.Name = "mnuControle";
            this.mnuControle.Size = new System.Drawing.Size(80, 24);
            this.mnuControle.Text = "C&ontrole";
            // 
            // mnuItemComissao
            // 
            this.mnuItemComissao.Name = "mnuItemComissao";
            this.mnuItemComissao.Size = new System.Drawing.Size(224, 26);
            this.mnuItemComissao.Text = "&Comissão";
            this.mnuItemComissao.Click += new System.EventHandler(this.mnuItemComissao_Click);
            // 
            // mnuAjuda
            // 
            this.mnuAjuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemSobre});
            this.mnuAjuda.Name = "mnuAjuda";
            this.mnuAjuda.Size = new System.Drawing.Size(62, 24);
            this.mnuAjuda.Text = "Aj&uda";
            // 
            // mnuItemSobre
            // 
            this.mnuItemSobre.Name = "mnuItemSobre";
            this.mnuItemSobre.Size = new System.Drawing.Size(131, 26);
            this.mnuItemSobre.Text = "S&obre";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 317);
            this.Controls.Add(this.mmMenu);
            this.MainMenuStrip = this.mmMenu;
            this.MaximizeBox = false;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Controle de Comissão";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPrincipal_FormClosing);
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.mmMenu.ResumeLayout(false);
            this.mmMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mmMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuArquivo;
        private System.Windows.Forms.ToolStripMenuItem mnuItemSair;
        private System.Windows.Forms.ToolStripMenuItem mnuCadastro;
        private System.Windows.Forms.ToolStripMenuItem mnuItemVendedor;
        private System.Windows.Forms.ToolStripMenuItem mnuControle;
        private System.Windows.Forms.ToolStripMenuItem mnuItemComissao;
        private System.Windows.Forms.ToolStripMenuItem mnuAjuda;
        private System.Windows.Forms.ToolStripMenuItem mnuItemSobre;
    }
}