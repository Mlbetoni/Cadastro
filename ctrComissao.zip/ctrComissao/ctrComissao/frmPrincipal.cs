﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ctrComissao
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void mnuItemSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuItemVendedor_Click(object sender, EventArgs e)
        {
            frmVendedor form = new frmVendedor();
            form.ShowDialog();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void frmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void mnuItemComissao_Click(object sender, EventArgs e)
        {
            frmComissao form = new frmComissao();
            form.ShowDialog();
        }
    }
}
