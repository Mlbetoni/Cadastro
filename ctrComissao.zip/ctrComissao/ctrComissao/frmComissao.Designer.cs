﻿namespace ctrComissao
{
    partial class frmComissao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpbOpcoes = new System.Windows.Forms.GroupBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnNovo = new System.Windows.Forms.Button();
            this.gpbDados = new System.Windows.Forms.GroupBox();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.lblLancamento = new System.Windows.Forms.Label();
            this.lblVendedor = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.mskData = new System.Windows.Forms.MaskedTextBox();
            this.txtCodVendedor = new System.Windows.Forms.TextBox();
            this.lblNomeVendedor = new System.Windows.Forms.Label();
            this.lblValor = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.txtPercentualComissao = new System.Windows.Forms.TextBox();
            this.lblPercentualComissao = new System.Windows.Forms.Label();
            this.txtTotalComissao = new System.Windows.Forms.TextBox();
            this.lblTotalComissao = new System.Windows.Forms.Label();
            this.gpbOpcoes.SuspendLayout();
            this.gpbDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpbOpcoes
            // 
            this.gpbOpcoes.Controls.Add(this.btnSair);
            this.gpbOpcoes.Controls.Add(this.btnPesquisar);
            this.gpbOpcoes.Controls.Add(this.btnCancelar);
            this.gpbOpcoes.Controls.Add(this.btnSalvar);
            this.gpbOpcoes.Controls.Add(this.btnNovo);
            this.gpbOpcoes.Location = new System.Drawing.Point(12, 12);
            this.gpbOpcoes.Name = "gpbOpcoes";
            this.gpbOpcoes.Size = new System.Drawing.Size(581, 91);
            this.gpbOpcoes.TabIndex = 1;
            this.gpbOpcoes.TabStop = false;
            this.gpbOpcoes.Text = "Opções";
            // 
            // btnSair
            // 
            this.btnSair.Image = global::ctrComissao.Properties.Resources.Sair;
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSair.Location = new System.Drawing.Point(449, 21);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(104, 58);
            this.btnSair.TabIndex = 0;
            this.btnSair.Text = "Sai&r";
            this.btnSair.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Image = global::ctrComissao.Properties.Resources.icons8_pesquisar_48;
            this.btnPesquisar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPesquisar.Location = new System.Drawing.Point(330, 21);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(113, 58);
            this.btnPesquisar.TabIndex = 0;
            this.btnPesquisar.Text = "&Pesquisa";
            this.btnPesquisar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = global::ctrComissao.Properties.Resources.Cancelar;
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(222, 21);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(104, 58);
            this.btnCancelar.TabIndex = 0;
            this.btnCancelar.Text = "C&ancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnSalvar
            // 
            this.btnSalvar.Image = global::ctrComissao.Properties.Resources.Salvar;
            this.btnSalvar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvar.Location = new System.Drawing.Point(114, 21);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(104, 58);
            this.btnSalvar.TabIndex = 0;
            this.btnSalvar.Text = "&Salvar";
            this.btnSalvar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalvar.UseVisualStyleBackColor = true;
            // 
            // btnNovo
            // 
            this.btnNovo.Image = global::ctrComissao.Properties.Resources.Novo__2_;
            this.btnNovo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNovo.Location = new System.Drawing.Point(6, 21);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(104, 58);
            this.btnNovo.TabIndex = 0;
            this.btnNovo.Text = "&Novo";
            this.btnNovo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNovo.UseVisualStyleBackColor = true;
            // 
            // gpbDados
            // 
            this.gpbDados.Controls.Add(this.txtTotalComissao);
            this.gpbDados.Controls.Add(this.lblTotalComissao);
            this.gpbDados.Controls.Add(this.txtPercentualComissao);
            this.gpbDados.Controls.Add(this.lblPercentualComissao);
            this.gpbDados.Controls.Add(this.txtValor);
            this.gpbDados.Controls.Add(this.lblValor);
            this.gpbDados.Controls.Add(this.lblNomeVendedor);
            this.gpbDados.Controls.Add(this.txtCodVendedor);
            this.gpbDados.Controls.Add(this.mskData);
            this.gpbDados.Controls.Add(this.lblData);
            this.gpbDados.Controls.Add(this.lblVendedor);
            this.gpbDados.Controls.Add(this.txtCodigo);
            this.gpbDados.Controls.Add(this.lblLancamento);
            this.gpbDados.Location = new System.Drawing.Point(12, 109);
            this.gpbDados.Name = "gpbDados";
            this.gpbDados.Size = new System.Drawing.Size(553, 202);
            this.gpbDados.TabIndex = 2;
            this.gpbDados.TabStop = false;
            this.gpbDados.Text = "Dados";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Enabled = false;
            this.txtCodigo.Location = new System.Drawing.Point(14, 48);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(100, 22);
            this.txtCodigo.TabIndex = 1;
            // 
            // lblLancamento
            // 
            this.lblLancamento.AutoSize = true;
            this.lblLancamento.Location = new System.Drawing.Point(11, 25);
            this.lblLancamento.Name = "lblLancamento";
            this.lblLancamento.Size = new System.Drawing.Size(105, 20);
            this.lblLancamento.TabIndex = 0;
            this.lblLancamento.Text = "Lançamento:";
            // 
            // lblVendedor
            // 
            this.lblVendedor.AutoSize = true;
            this.lblVendedor.Location = new System.Drawing.Point(14, 83);
            this.lblVendedor.Name = "lblVendedor";
            this.lblVendedor.Size = new System.Drawing.Size(70, 16);
            this.lblVendedor.TabIndex = 2;
            this.lblVendedor.Text = "Vendedor:";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(14, 137);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(39, 16);
            this.lblData.TabIndex = 5;
            this.lblData.Text = "Data:";
            // 
            // mskData
            // 
            this.mskData.Location = new System.Drawing.Point(17, 159);
            this.mskData.Mask = "00/00/0000";
            this.mskData.Name = "mskData";
            this.mskData.Size = new System.Drawing.Size(83, 22);
            this.mskData.TabIndex = 6;
            this.mskData.ValidatingType = typeof(System.DateTime);
            // 
            // txtCodVendedor
            // 
            this.txtCodVendedor.Location = new System.Drawing.Point(17, 102);
            this.txtCodVendedor.Name = "txtCodVendedor";
            this.txtCodVendedor.Size = new System.Drawing.Size(95, 22);
            this.txtCodVendedor.TabIndex = 7;
            // 
            // lblNomeVendedor
            // 
            this.lblNomeVendedor.AutoSize = true;
            this.lblNomeVendedor.Location = new System.Drawing.Point(118, 102);
            this.lblNomeVendedor.Name = "lblNomeVendedor";
            this.lblNomeVendedor.Size = new System.Drawing.Size(129, 16);
            this.lblNomeVendedor.TabIndex = 8;
            this.lblNomeVendedor.Text = "Nome do Vendedor:";
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Location = new System.Drawing.Point(118, 137);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(42, 16);
            this.lblValor.TabIndex = 9;
            this.lblValor.Text = "Valor:";
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(121, 159);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(97, 22);
            this.txtValor.TabIndex = 10;
            // 
            // txtPercentualComissao
            // 
            this.txtPercentualComissao.Enabled = false;
            this.txtPercentualComissao.Location = new System.Drawing.Point(262, 159);
            this.txtPercentualComissao.Name = "txtPercentualComissao";
            this.txtPercentualComissao.Size = new System.Drawing.Size(45, 22);
            this.txtPercentualComissao.TabIndex = 12;
            // 
            // lblPercentualComissao
            // 
            this.lblPercentualComissao.AutoSize = true;
            this.lblPercentualComissao.Location = new System.Drawing.Point(259, 137);
            this.lblPercentualComissao.Name = "lblPercentualComissao";
            this.lblPercentualComissao.Size = new System.Drawing.Size(86, 16);
            this.lblPercentualComissao.TabIndex = 11;
            this.lblPercentualComissao.Text = "% Comissão:";
            // 
            // txtTotalComissao
            // 
            this.txtTotalComissao.Location = new System.Drawing.Point(363, 159);
            this.txtTotalComissao.Name = "txtTotalComissao";
            this.txtTotalComissao.ReadOnly = true;
            this.txtTotalComissao.Size = new System.Drawing.Size(97, 22);
            this.txtTotalComissao.TabIndex = 14;
            // 
            // lblTotalComissao
            // 
            this.lblTotalComissao.AutoSize = true;
            this.lblTotalComissao.Location = new System.Drawing.Point(360, 137);
            this.lblTotalComissao.Name = "lblTotalComissao";
            this.lblTotalComissao.Size = new System.Drawing.Size(124, 16);
            this.lblTotalComissao.TabIndex = 13;
            this.lblTotalComissao.Text = "Total da Comissão:";
            // 
            // frmComissao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 324);
            this.Controls.Add(this.gpbDados);
            this.Controls.Add(this.gpbOpcoes);
            this.MaximizeBox = false;
            this.Name = "frmComissao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Controle de Comissão";
            this.gpbOpcoes.ResumeLayout(false);
            this.gpbDados.ResumeLayout(false);
            this.gpbDados.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbOpcoes;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.GroupBox gpbDados;
        private System.Windows.Forms.Label lblLancamento;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.Label lblVendedor;
        private System.Windows.Forms.TextBox txtCodVendedor;
        private System.Windows.Forms.MaskedTextBox mskData;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.Label lblNomeVendedor;
        private System.Windows.Forms.TextBox txtTotalComissao;
        private System.Windows.Forms.Label lblTotalComissao;
        private System.Windows.Forms.TextBox txtPercentualComissao;
        private System.Windows.Forms.Label lblPercentualComissao;
        private System.Windows.Forms.TextBox txtValor;
    }
}