﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ctrComissao
{
    public partial class frmVendedor : Form
    {
        public frmVendedor()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Dispose(); // Fecha o formulário, e descarrega da memória.
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = false;
            btnSalvar.Enabled = true;
            chkSituacao.Text = "Ativo";
            chkSituacao.Enabled = false;
            chkSituacao.Checked = true;
            btnNovo.Tag = "Novo";
            gpbDados.Enabled = true;
            txtVendedor.Focus();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = true;
            btnSalvar.Enabled = false;
            gpbDados.Enabled = false;
            limpar();
        }

        private void limpar()
        {
            foreach (Control ctl in gpbDados.Controls)
            {
                if (ctl is TextBox) ctl.Text = "";
                if (ctl is MaskedTextBox) ctl.Text = "";
                if (ctl is ComboBox) ctl.Text = "";
                if (ctl is CheckBox) (ctl as CheckBox).Checked = false;
            }
        }

        private void frmVendedor_Load(object sender, EventArgs e)
        {
            btnCancelar_Click(sender, e);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtVendedor.Text))
            {
                MessageBox.Show("Digite o nome do vendedor!", "Vendedor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtVendedor.Focus();
                return;
            }

            if (MessageBox.Show("Deseja Salvar ?","Salvar",MessageBoxButtons.YesNo)==DialogResult.Yes)
            {
                try
                {
                    clsVendedor classeVendedor = new clsVendedor();
                    if (btnNovo.Tag.ToString() == "Editar") // Se clicou no DataGrid.
                    {
                        string situacao = "";
                        if (chkSituacao.Checked)
                        {
                            situacao = "A";
                        }
                        else
                        {
                            situacao = "I";
                        }

                        classeVendedor.editar(Convert.ToInt32(txtCodigo.Text), txtVendedor.Text, txtEmail.Text, mskContato.Text, Convert.ToDouble(txtPercentualComissao.Text));
                    }
                    else
                    {
                        classeVendedor.inserir(txtVendedor.Text, txtEmail.Text, mskContato.Text, Convert.ToDouble(txtPercentualComissao.Text));
                    }
                    MessageBox.Show("Vendedor salvo com sucesso!", "Vendedor", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
