﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ctrComissao
{
    public class clsUsuario
    {
        // Inicialização das classes de conexão, de inserção, edição e pesquisa (select) dos dados
        SqlConnection cn = new SqlConnection(); // Faz a conexão com o banco
        SqlCommand cmd = new SqlCommand(); // Permite utilizar os comandos: insert, update, delete, select
        DataTable dt = new DataTable(); // Permite selecionar os registros da tabela

        public DataTable PesquisaUsuario(string nome, string senha)
        {
            SqlConnection cn = new SqlConnection(clsConexao.StringConexao);

            try
            {
                cn.Open(); // Abre a conexão
                string SQL = "SELECT * FROM tbusuario WHERE nome = @nome AND senha = @senha";
                SqlCommand cmd = new SqlCommand(SQL, cn);
                cmd.Parameters.Add(new SqlParameter("@nome", nome));
                cmd.Parameters.Add(new SqlParameter("@senha", senha));

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                return dt;
            } 
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
                cmd.Dispose();
            }
        }


    }
}
