﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ctrComissao
{
    public partial class frmLogin : Form
    {
        int contador = 0;
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAcessar_Click(object sender, EventArgs e)
        {
            contador += 1; // Adiciona mais na variável contador
            try
            {
                clsUsuario classeUsuario = new clsUsuario();
                DataTable resultado = classeUsuario.PesquisaUsuario(txtNome.Text, txtSenha.Text);

                if (resultado.Rows.Count > 0)
                {
                    this.Hide();
                    frmPrincipal form = new frmPrincipal();
                    form.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Usuário ou Senha Inválida!", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    if (contador > 3)
                    {
                        MessageBox.Show("Acesso não permitido!", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Application.Exit();
                    }

                    txtNome.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Possível erro: Acesso ao servidor!" + "\n\n" + ex.Message);
            }
            
        }

        private void lblNome_DoubleClick(object sender, EventArgs e)
        {
            txtNome.Text = "admin";
            txtSenha.Text = "1234";
        }
    }
}
