﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ctrComissao
{
    public class clsConexao
    {
        private static string conexao = @"Data Source=.\SQLEXPRESS; Initial Catalog=bdcomissao; user id=sa; password=sa";

        public static string StringConexao
        {
            get { return conexao; }
        }
    }
}
